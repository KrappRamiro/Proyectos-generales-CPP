#ifndef UTILS_H
#define UTILS_H
#include <iostream>
#include <vector>
#include <string>
#include "client.h"

void mostrarMenu(std::vector<Client> & clients);
#endif

